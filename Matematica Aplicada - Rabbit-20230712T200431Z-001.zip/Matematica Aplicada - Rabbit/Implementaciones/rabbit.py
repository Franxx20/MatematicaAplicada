class RabbitCipher:
    def __init__(self, key, iv):
        if len(key) != 16:
            raise ValueError("La clave debe tener una longitud de 128 bits (16 bytes).")
        if len(iv) != 8:
            raise ValueError("El vector de inicialización (IV) debe tener una longitud de 64 bits (8 bytes).")
        
        self.x = [0] * 8
        self.c = [0] * 8
        
        # Inicializar los registros internos x y c con la clave y el IV
        for i in range(8):
            self.x[i] = (key[i * 4] << 24) | (key[i * 4 + 1] << 16) | (key[i * 4 + 2] << 8) | key[i * 4 + 3]
            self.c[i] = (iv[i * 4] << 24) + (iv[i * 4 + 1] << 16) + (iv[i * 4 + 2] << 8) + iv[i * 4 + 3]
        
        # Realizar configuraciones adicionales necesarias antes de la encriptación/desencriptación
        # ...
    
    def encrypt(self, plaintext):
        block_count = len(plaintext) // 16
        ciphertext = bytearray()
        
        for i in range(block_count):
            keystream = self.generate_keystream()
            
            for j in range(16):
                ciphertext.append(plaintext[i * 16 + j] ^ (keystream[j] & 0xFF))
        
        return ciphertext
    
    def decrypt(self, ciphertext):
        block_count = len(ciphertext) // 16
        plaintext = bytearray()
        
        for i in range(block_count):
            keystream = self.generate_keystream()
            
            for j in range(16):
                plaintext.append(ciphertext[i * 16 + j] ^ (keystream[j] & 0xFF))
        
        return plaintext
    
    def generate_keystream(self):
        # Implementar el proceso de generación de la secuencia clave pseudoaleatoria
        # utilizando los registros internos x y c y las rondas de Rabbit
        
        keystream = [0] * 16
        
        # ...
        for i in range(8):
            g_func = (self.x[i] + self.c[i]) & 0xFFFFFFFF
        
        # Ronda A
            self.x[(i + 4) & 7] ^= g_func
            self.c[(i + 1) & 7] = (self.c[(i + 1) & 7] + self.x[i]) & 0xFFFFFFFF
        
        # Ronda B
            self.x[(i + 2) & 7] ^= self.c[(i + 1) & 7]
            self.c[(i + 5) & 7] = (self.c[(i + 5) & 7] + self.x[(i + 2) & 7]) & 0xFFFFFFFF
        
        # Ronda C
            self.x[(i + 6) & 7] ^= self.c[(i + 5) & 7]
            self.c[(i + 3) & 7] = (self.c[(i + 3) & 7] + self.x[(i + 6) & 7]) & 0xFFFFFFFF
        
        # Ronda D
            self.x[i] ^= self.c[(i + 3) & 7]
            self.c[(i + 7) & 7] = (self.c[(i + 7) & 7] + self.x[i]) & 0xFFFFFFFF
        
        # Actualizar el keystream
            keystream[i] = (g_func & 0xFF)
            keystream[i + 8] = (g_func >> 8) & 0xFF
    
        return keystream

# Ejemplo de uso
key = bytes.fromhex("00112233445566778899AABBCCDDEEFF")
iv = bytes.fromhex("0102030405060708")
plaintext = bytes.fromhex("112233445566778899AABBCCDDEEFF00")

cipher = RabbitCipher(key, iv)
ciphertext = cipher.encrypt(plaintext)
decrypted_text = cipher.decrypt(ciphertext)

print("Texto cifrado:", ciphertext.hex())
print("Texto descifrado:", decrypted_text.hex())