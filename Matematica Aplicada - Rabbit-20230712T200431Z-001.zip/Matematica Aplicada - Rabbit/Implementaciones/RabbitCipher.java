public class RabbitCipher {
    private int[] x = new int[8];
    private int[] c = new int[8];

    public RabbitCipher(byte[] key, byte[] iv) {
        if (key.length != 16) {
            throw new IllegalArgumentException("La clave debe tener una longitud de 128 bits (16 bytes).");
        }
        if (iv.length != 8) {
            throw new IllegalArgumentException("El vector de inicialización (IV) debe tener una longitud de 64 bits (8 bytes).");
        }

        // Inicializar los registros internos x y c con la clave y el IV
        for (int i = 0; i < 2; i++) {
            x[i] = ((key[i * 4] & 0xFF) << 24) | ((key[i * 4 + 1] & 0xFF) << 16) |
                    ((key[i * 4 + 2] & 0xFF) << 8) | (key[i * 4 + 3] & 0xFF);
            c[i] = ((iv[i * 4] & 0xFF) << 24) | ((iv[i * 4 + 1] & 0xFF) << 16) |
                    ((iv[i * 4 + 2] & 0xFF) << 8) | (iv[i * 4 + 3] & 0xFF);
        }

        // Realizar configuraciones adicionales necesarias antes de la encriptación/desencriptación
        // ...
    }

    public byte[] encrypt(byte[] plaintext) {
        int blockCount = plaintext.length / 16;
        byte[] ciphertext = new byte[plaintext.length];

        for (int i = 0; i < blockCount; i++) {
            int[] keystream = generateKeystream();

            for (int j = 0; j < 16; j++) {
                ciphertext[i * 16 + j] = (byte) (plaintext[i * 16 + j] ^ (keystream[j] & 0xFF));
            }
        }

        return ciphertext;
    }

    public byte[] decrypt(byte[] ciphertext) {
        int blockCount = ciphertext.length / 16;
        byte[] plaintext = new byte[ciphertext.length];

        for (int i = 0; i < blockCount; i++) {
            int[] keystream = generateKeystream();

            for (int j = 0; j < 16; j++) {
                plaintext[i * 16 + j] = (byte) (ciphertext[i * 16 + j] ^ (keystream[j] & 0xFF));
            }
        }

        return plaintext;
    }

    private int[] generateKeystream() {
        // Implementar el proceso de generación de la secuencia clave pseudoaleatoria
        // utilizando los registros internos x y c y las rondas de Rabbit

        int[] keystream = new int[16];

        // ...

        return keystream;
    }


    public static void main(String[] args) {
        byte[] key = {
                (byte)0x00,(byte) 0x11,(byte) 0x22, (byte)0x33,(byte) 0x44,(byte) 0x55,(byte) 0x66,(byte) 0x77,
                (byte) 0x88, (byte) 0x99, (byte) 0xAA, (byte) 0xBB,
                (byte) 0xCC, (byte) 0xDD, (byte) 0xEE, (byte) 0xFF
        };

        byte[] iv = {
                0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08
        };

        byte[] plaintext = {
                (byte)0x11,(byte) 0x22,(byte) 0x33,(byte) 0x44,(byte) 0x55,(byte) 0x66,(byte) 0x77, (byte) 0x88,
                (byte) 0x99, (byte) 0xAA, (byte) 0xBB, (byte) 0xCC,
                (byte) 0xDD, (byte) 0xEE, (byte) 0xFF, (byte) 0x00
        };

        RabbitCipher cipher = new RabbitCipher(key, iv);

        // Encriptar
        byte[] ciphertext = cipher.encrypt(plaintext);
        System.out.println("Texto cifrado: " + bytesToHex(ciphertext));

        // Desencriptar
        byte[] decryptedText = cipher.decrypt(ciphertext);
        System.out.println("Texto descifrado: " + bytesToHex(decryptedText));
    }

    private static String bytesToHex(byte[] bytes) {
        StringBuilder sb = new StringBuilder();
        for (byte b : bytes) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString();
    }
}


